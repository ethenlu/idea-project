package com.anxpp.tinysoft.controller;

import org.springframework.stereotype.Controller;

/**
 * 默认页面
 * Created by anxpp.com on 2017/3/11.
 */
@Controller
//@RequestMapping("/")
public class IndexController {

//    @RequestMapping("/")
//    public String getArticleByStage() {
//        return "index";
//    }
}