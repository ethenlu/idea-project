package com.anxpp.tinysoft.Utils;

import org.springframework.stereotype.Component;

/**
 * 文章获取工具
 * Created by anxpp.com on 2017/3/11.
 */
@Component
public class worker {
}
