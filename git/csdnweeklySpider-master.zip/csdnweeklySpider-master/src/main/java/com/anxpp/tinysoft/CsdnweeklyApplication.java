package com.anxpp.tinysoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsdnweeklyApplication {

	public static void main(String[] args) {
		SpringApplication.run(CsdnweeklyApplication.class, args);
	}
}
